export class LogoutButton {
    logout() {
      it('should log out', () => {
        cy.visit('/dashboard');
        cy.get('.fdx-main-nav-item-label').click();
        cy.get('.fdx-sub-nav-menu-item-label').click();
        cy.url().should('include', 'https://ryze-staging.formedix.com/');
      });
    }
  }
  
  const logoutButton = new LogoutButton();
  export default logoutButton;