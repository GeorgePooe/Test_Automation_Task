export class ViewForms {
    viewForms() {
      it('should view forms', () => {
        cy.contains('Repository').should('contain', 'Repository').click();
        cy.contains('Studies').should('contain', 'Studies').click();
        cy.get('.fdxicon-regular.fdx-menu.dropdown-toggle.icon').click();
        cy.contains('View').should('contain', 'View').click();
        cy.get('#FORMTypeName').should('contain', 'Forms');
        cy.contains('Forms View').should('be.visible');
      });
    }
  
    MedicalHistory() {
      it('should view Medical History', () => {
        cy.contains('Medical History').should('contain', 'Medical History').click();
        cy.contains('Edit form').should('contain', 'Edit form').click();
        cy.contains('Add').should('contain', 'Add').click();
        cy.get('#assetLocaleEditTextTextareadescription').type('Description');
        cy.contains('Update').should('contain', 'Update').click();
        cy.should('Description: Description');
      });
    }
  }
  
  const viewForms = new ViewForms();
  export default viewForms;
  