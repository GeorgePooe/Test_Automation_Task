import loginPage from './login';
import viewForms from './View_Forms';
import logoutButton from './logout';

function executeTestSuite() {
  loginPage.login(loginData.username, loginData.password);
  viewForms.viewForms();
  viewForms.MedicalHistory();
  logoutButton.logout();
}

export default executeTestSuite;